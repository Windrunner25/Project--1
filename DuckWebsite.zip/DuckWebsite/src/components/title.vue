<template>
  <v-sheet
    class="d-flex align-center justify-center flex-wrap text-center mx-auto px-4 mt-5"
    elevation="4"
    height="250"
    max-width="800"
    width="100%"
    rounded
  >
    <div>
      <h2 class="text-h4 font-weight-black text-orange mb-5">
        Welcome to Premier Ducks!
      </h2>
      <div class="text-h5 font-weight-light mb-5">
        If you are interested in purchasing a duck, head over to our shop.
      </div>

      <v-btn color="orange" variant="text" to="/shop">Go to Shop</v-btn>
    </div>
  </v-sheet>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Title", // Ensure the name matches what you're importing
});
</script>
